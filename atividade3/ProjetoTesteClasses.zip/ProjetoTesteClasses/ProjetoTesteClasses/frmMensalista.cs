﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoTesteClasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void frmMensalista_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnInstancia1_Click(object sender, EventArgs e)
        {
            Mensalista objHorista = new Mensalista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.SalarioMensal = Convert.ToInt32(txtSalario.Text);
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);

            MessageBox.Show(
                  "nome: " + objHorista.NomeEmpregado
                + "\n matricula: " + objHorista.Matricula
                + "\n tempo trabalho: " + objHorista.TempoTrabalho() + " dias"
                + "\n salario: " + objHorista.SalarioBruto().ToString("N2"));
            MessageBox.Show("empresa: " +Mensalista.empresa);
        }

        private void btnInstancia2_Click(object sender, EventArgs e)
        {        
            Mensalista objMensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSalario.Text));

            MessageBox.Show(
                  "nome: " + objMensalista.NomeEmpregado
                + "\n matricula: " + objMensalista.Matricula
                + "\n tempo trabalho: " + objMensalista.TempoTrabalho() + " dias"
                + "\n salario: " + objMensalista.SalarioBruto().ToString("N2"));
        
        }
    }
}
